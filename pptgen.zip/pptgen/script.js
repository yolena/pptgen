function doTestSimple() {
			var pptx = new PptxGenJS();
			var slide = pptx.addNewSlide();
			var optsTitle = { color:'9F9F9F', marginPt:3, border:[0,0,{pt:'1',color:'CFCFCF'},0] };

			pptx.setLayout({ name:'A3', width:16.5, height:11.7 });

			slide.slideNumber({ x:0.5, y:'90%' });

			slide.addTable( [ [{ text:'Simple Example', options:optsTitle }] ], { x:0.5, y:0.13, w:12.5 } );

			//slide.addText('Hello World!', { x:0.5, y:0.7, w:6, h:1, color:'0000FF' });
			slide.addText('Hello 45! ', { x:0.5, y:0.5, w:6, h:1, fontSize:36, color:'0000FF', shadow:{type:'outer', color:'00AAFF', blur:2, offset:10, angle: 45, opacity:0.25} });
			slide.addText('Hello 180!', { x:0.5, y:1.0, w:6, h:1, fontSize:36, color:'0000FF', shadow:{type:'outer', color:'ceAA00', blur:2, offset:10, angle:180, opacity:0.5} });
			slide.addText('Hello 355!', { x:0.5, y:1.5, w:6, h:1, fontSize:36, color:'0000FF', shadow:{type:'outer', color:'aaAA33', blur:2, offset:10, angle:355, opacity:0.75} });

			// Bullet Test: Number
			slide.addText(999, { x:0.5, y:2.0, w:'50%', h:1, color:'0000DE', bullet:true });
			// Bullet Test: Text test
			slide.addText('Bullet text', { x:0.5, y:2.5, w:'50%', h:1, color:'00AA00', bullet:true });
			// Bullet Test: Multi-line text test
			slide.addText('Line 1\nLine 2\nLine 3', { x:0.5, y:3.5, w:'50%', h:1, color:'AACD00', bullet:true });

			// Table cell margin:0
			slide.addTable( [['margin:0']], { x:0.5, y:1.1, margin:0, w:0.75, fill:'FFFCCC' } );

			// Fine-grained Formatting/word-level/line-level Formatting
			slide.addText(
				[
					{ text:'right line', options:{ fontSize:24, fontFace:'Courier New', color:'99ABCC', align:'r', breakLine:true } },
					{ text:'ctr line',   options:{ fontSize:36, fontFace:'Arial',       color:'FFFF00', align:'c', breakLine:true } },
					{ text:'left line',  options:{ fontSize:48, fontFace:'Verdana',     color:'0088CC', align:'l' } }
				],
				{ x:0.5, y:3.0, w:8.5, h:4, margin:0.1, fill:'232323' }
			);

			// Export:
			pptx.save('Sample Presentation');
        }

function doTestSimpleImage() {
            var pptx = new PptxGenJS();
            var slide = pptx.addNewSlide();
            
            // EX: Image by local URL
            slide.addImage({ path:'images/image.png', x:1, y:1, w:4.0, h:4.0 });

            // EX: Image from remote URL
            //slide.addImage({ path:'https://upload.wikimedia.org/wikipedia/en/a/a9/Example.jpg', x:1, y:1, w:6, h:4 })
            
            pptx.save('Demo-Images');
        }
        